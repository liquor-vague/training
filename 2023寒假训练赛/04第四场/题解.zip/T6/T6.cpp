#include <bits/stdc++.h>

using namespace std;

#define x first
#define y second

typedef pair<int, int> pii;
typedef long long ll;

const int N = 1e5 + 5, M = N * 2;

int n, k, a[N];
int dp[N][21];
pii q[N];

struct node
{
    int l, r;
    int mx[21];
}tr[N << 2];

void build(int u, int l, int r)
{
    tr[u] = {l, r};
    if(l == r)return;
    int mid = l + r >> 1;
    build(u << 1, l, mid);
    build(u << 1 | 1, mid + 1, r);
}

void pushup(int i, int u)
{
    tr[u].mx[i] = max(tr[u << 1].mx[i], tr[u << 1 | 1].mx[i]);
}

void modify(int i, int u, int pos, int val)
{
    if(tr[u].l == tr[u].r)
    {
        tr[u].mx[i] = val;
        return;
    }
    int mid = tr[u].l + tr[u].r >> 1;
    if(pos <= mid)modify(i, u << 1, pos, val);
    else modify(i, u << 1 | 1, pos, val);
    pushup(i, u);
}

int ask(int i, int u, int l, int r)
{
    if(tr[u].l >= l && tr[u].r <= r)
        return tr[u].mx[i];
    int mid = tr[u].l + tr[u].r >> 1;
    int ans = 0;
    if(l <= mid)ans = ask(i, u << 1, l, r);
    if(r > mid)ans = max(ans, ask(i, u << 1 | 1, l, r));
    return ans;
}

int main()
{
    scanf("%d%d", &n, &k);
    for(int i = 2; i <= n; ++i)
        scanf("%d", &a[i]);
    for(int i = 2; i <= n; ++i)
        scanf("%d%d", &q[i].x, &q[i].y);
    
    int ans = 0;
    build(1, 1, n);
    for(int i = 2; i <= n; ++i)
        for(int j = 0; j <= k; ++j)
        {
            if(!j)dp[i][j] = ask(j, 1, q[i].x, q[i].y) + a[i];
            else dp[i][j] = max(ask(j, 1, q[i].x, q[i].y), ask(j - 1, 1, 1, i - 1)) + a[i];
            modify(j, 1, i, dp[i][j]);
            ans = max(ans, dp[i][j]);
        }

    printf("%d\n", ans);
    return 0;
}