#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

const int N = 1e3 + 5;
const int mod = 1e9 + 7;

int n, m, k;
int dp[N][N];
 
int ksm(int a, int k, int p = mod)
{
    int res = 1;
    while(k)
    {
        if(k & 1)res = (ll)res * a % p;
        a = (ll)a * a % p;
        k >>= 1;
    }
    return res;
}
 
int main()
{
    cin >> n >> m >> k;
    dp[0][0] = 1;
    for(int j = 1; j <= k; ++j)
        for(int i = 0; i <= n; ++i)
            for(int x = 1; x <= m; ++x)
            {
                if(i >= x)
                    dp[i][j] = (dp[i][j] + 
                        (ll)dp[i - x][j - 1] * ksm(m, mod - 2)) % mod;
                if(2 * n - i - x >= 0 && 2 * n - i - x < n && i != n)
                    dp[i][j] = (dp[i][j] + 
                        (ll)dp[2 * n - i - x][j - 1] * ksm(m, mod - 2)) % mod;
            }
 
    int ans = 0;
    for(int i = 1; i <= k; ++i)
        ans = ((ll)ans + dp[n][i]) % mod;
    printf("%d\n", ans);
    return 0;
}