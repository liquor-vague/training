#include <bits/stdc++.h>

using namespace std;

char str[1005][1005], s[1005];
int n;

void to_fill(int x1, int y1, int x2, int y2, char ch)
{
    for(int i = y1; i <= y2; ++i)
        str[x1][i] = str[x2][i] = ch;
    for(int j = x1; j <= x2; ++j)
        str[j][y1] = str[j][y2] = ch;
}

int main()
{
    scanf("%d", &n);
    scanf("%s", s + 1);
    for(int i = 1; i <= (n + 1) / 2; ++i)
        to_fill(i, i, n - i + 1, n - i + 1, s[i]);
    for(int i = 1; i <= n; ++i)
        puts(str[i] + 1);
    return 0;
}