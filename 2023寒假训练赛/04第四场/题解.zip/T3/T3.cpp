#include<bits/stdc++.h>
using namespace std;
#define endl '\n'

const int maxn = 2e5+5;
int a[maxn];

bool solve() {
	int n;
	vector<int> flag(4, 0); // 有四种状态, 分别是余数为0, 余数为1、2、4和余数为3、6、5的两种情况
	cin>>n;
	for (int i=1;i<=n;i++) 
		cin>>a[i];
	for (int i=1;i<=n;i++) {
		int r = a[i] % 7;
		if (r == 0) {
			flag[0] = 1;
		} else if (r == 1 || r == 2 || r == 4) {
			flag[1] = 1;
		} else if (r == 3 || r == 6 || r == 5) {
			while (a[i] % 7 != 3) 
				a[i] += a[i] % 7;
			flag[2 + ((a[i]-3)/7 & 1)] = 1;
		}
		if (accumulate(flag.begin(), flag.end(), 0) > 1) 
			return false;
	}
	if (flag[0]) {
		for (int i=2;i<=n;i++) 
			if (a[i] != a[1]) 
				return false;
	}
	return true;
}

int main() {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	int T;
	cin>>T;
	while (T--) {
		cout<<(solve()? 666:67)<<endl;
	}
}