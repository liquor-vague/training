#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
//#define int ll
#define endl '\n'
#define fup(i, a, b) for(int i=(a);i<=(b);i++)
#define fdo(i, a, b) for(int i=(a);i>=(b);i--)
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug(x) cout<<#x<<" = "<<x<<endl
#define mem(a, b) memset(a, b, sizeof(a))
#define rf freopen("in.txt", "r", stdin)
#define wf freopen("out.txt", "w", stdout)
#define lowbit(x) ((x) & (-x))

const int maxn = 1e5+10;
int tree[maxn];

inline void update(int i, int x) {
    for (int pos = i; pos < maxn; pos += lowbit(pos))
        tree[pos] += x;
}
inline int query(int n) {
    int ans = 0;
    for (int pos = n; pos; pos -= lowbit(pos))
        ans += tree[pos];
    return ans;
}
inline int query(int a, int b) {
    return query(b) - query(a-1);
}

int main() {
    io;
    int n, m, k, w;
    cin>>n>>m;
    map<int, int> ma;
    fdo (i, n, 1) {
        cin>>w;
        ma[w] = i;
        update(i, 1);
    }
    fup (i, n+2, n+m+1) {
        cin>>w;
        ma[w] = i;
        update(i, 1);
    }
    int top = n+1;
    cin>>k;
    fup (i, 1, k) {
        cin>>w;
        int idx = ma[w];
        if (idx == 0) {
            std::cout << "-1\n";
            continue;
        }
        else if (top > idx) {
            cout<<query(idx, top)-1<<endl;
        } else {
            cout<<query(top, idx)-1<<endl;
        }
        update(idx, -1);
        ma[w] = 0;
        top = idx;
    }
}