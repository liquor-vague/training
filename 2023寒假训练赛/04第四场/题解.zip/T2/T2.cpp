#include <bits/stdc++.h>

using namespace std;

typedef long long ll;

ll n;

bool check(ll mid)
{
    ll sum = 0, t = n;
    while(t)
    {
        sum += min(t, mid);
        t -= min(t, mid);
        t -= t / 10;
    }
    return sum * 2 >= n;
}

void solve()
{
    cin >> n;
    ll l = 1, r = n, ans = -1;
    while(l <= r)
    {
        ll mid = l + r >> 1;
        if(check(mid))
            ans = mid, r = mid - 1;
        else l = mid + 1;
    }
    printf("%lld\n", ans);
}

int main()
{
    int T;
    cin >> T;
    while(T --)
        solve();
    return 0;
}